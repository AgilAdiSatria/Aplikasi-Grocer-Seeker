﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace GrocerSeeker
{
    public partial class FormCreateAccount : Form
    {
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private DataSet ds;
        private SqlDataReader rd;

        Koneksi Konn = new Koneksi();

        public FormCreateAccount()
        {
            InitializeComponent();
            this.Text = "GrocerSeeker";

        }

        void Disablegb()
        {
            gbVendor.Enabled = false;
            gbCustomer.Enabled = false;
        }

        private void cekbCostomer_CheckedChanged(object sender, EventArgs e)
        {
            gbCustomer.Enabled = cekbCostomer.Checked;

            if (!cekbCostomer.Checked)
            {
                gbCustomer.Enabled = false;
            }
        }

        private void cekbVendor_CheckedChanged(object sender, EventArgs e)
        {
            gbVendor.Enabled = cekbVendor.Checked;

            if (!cekbVendor.Checked)
            {
                gbVendor.Enabled = false;
            }
        }

        private void CenterMessageLabel()
        {
            MessageCreate.Left = (this.ClientSize.Width - MessageCreate.Width) / 2;
        }


        private void FormCreateAccount_Load(object sender, EventArgs e)
        {
            Disablegb();
            MessageCreate.Visible = false;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // Validasi field utama
            if (string.IsNullOrEmpty(txtPhone.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtConfirmPassword.Text))
            {
                MessageCreate.Text = "Harap isi Field phone number, Email, password, dan Confirm Password terlebih dahulu";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            }

            // Validasi password
            if (!IsValidPassword(txtPassword.Text))
            {
                MessageCreate.Text = "Password harus minimal 8 karakter dengan kombinasi huruf besar, huruf kecil, dan angka";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            }

            // Validasi password dan confirm password
            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageCreate.Text = "Password dan Confirm Password anda tidak sesuai";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            }

            //validasi nomor telepon

            if (txtPhone.Text.Length < 10)
            {
                MessageCreate.Text = "Panjang Nomor Telepon Tidak Memenuhi Standar";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            } else if (txtPhone.Text.Length > 15)
            {
                MessageCreate.Text = "Panjang Nomor Telepon Melebihi Standar";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            }

            //Validasi Email

            if (!IsValidEmail(txtEmail.Text))
            {
                MessageCreate.Text = "Format email yang Anda masukkan tidak valid";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            }

            // Validasi role (Vendor atau Customer)
            if (!cekbVendor.Checked && !cekbCostomer.Checked)
            {
                MessageCreate.Text = "Harap pilih minimal salah satu role Vendor atau Customer terlebih dahulu";
                CenterMessageLabel();
                MessageCreate.Visible = true;
                return;
            }


            // Validasi Field Customer dan Vendor Detail
            if (cekbVendor.Checked && cekbCostomer.Checked)
            {
                if (string.IsNullOrEmpty(txtNameCustomer.Text) || string.IsNullOrEmpty(txtAddressCustomer.Text) || string.IsNullOrEmpty(txtLatitudeCustomer.Text) || string.IsNullOrEmpty(txtLongitudeCustomer.Text) ||
                    string.IsNullOrEmpty(txtNameVendor.Text) || string.IsNullOrEmpty(txtAddressVendor.Text) || string.IsNullOrEmpty(txtLatitudeVendor.Text) || string.IsNullOrEmpty(txtLongitudeVendor.Text))
                {
                    MessageCreate.Text = "Harap isi semua Field untuk Vendor dan Customer Detail terlebih dahulu";
                    CenterMessageLabel();
                    MessageCreate.Visible = true;
                    return;
                }
            }
            // Validasi Field Customer Detail
            else if (cekbCostomer.Checked)
            {
                if (string.IsNullOrEmpty(txtNameCustomer.Text) || string.IsNullOrEmpty(txtAddressCustomer.Text) || string.IsNullOrEmpty(txtLatitudeCustomer.Text) || string.IsNullOrEmpty(txtLongitudeCustomer.Text))
                {
                    MessageCreate.Text = "Harap isi semua field untuk Customer Detail terlebih dahulu";
                    CenterMessageLabel();
                    MessageCreate.Visible = true;
                    return;
                }
            }
            // Validasi Field Vendoe Detail
            else if (cekbVendor.Checked)
            {
                if (string.IsNullOrEmpty(txtNameVendor.Text) || string.IsNullOrEmpty(txtAddressVendor.Text) || string.IsNullOrEmpty(txtLatitudeVendor.Text) || string.IsNullOrEmpty(txtLongitudeVendor.Text))
                {
                    MessageCreate.Text = "Harap isi semua field untuk Vendor Detail terlebih dahulu";
                    CenterMessageLabel();
                    MessageCreate.Visible = true;
                    return;
                }
            }


            // Validasi nomor telepon dan email
            bool isPhoneExist = false;
            bool isEmailExist = false;

            SqlConnection conn = Konn.GetConn();
            conn.Open();

            cmd = new SqlCommand("Select Count (*) From [users] Where phone_number = @phone_number", conn);
            {
                cmd.Parameters.AddWithValue("@phone_number", txtPhone.Text);
                isPhoneExist = (int)cmd.ExecuteScalar() > 0;
            }
            cmd = new SqlCommand("Select Count (*) From [users] Where email = @email", conn);
            {
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                isEmailExist = (int)cmd.ExecuteScalar() > 0;
            }

            if (isPhoneExist && isEmailExist)
            {
                MessageBox.Show("Nomor Telepon dan Email sudah terdaftar di database");
                return;
            }
            else if (isEmailExist)
            {
                MessageBox.Show("Email sudah terdaftar di database");
                return;
            }
            else if (isPhoneExist)
            {
                MessageBox.Show("Nomor Telepon sudah terdaftar di database");
                return;
            }

            cmd = new SqlCommand("Select Isnull (Max(id),0) + 1 From [users]", conn);
            int newid = (int)cmd.ExecuteScalar();

            cmd = new SqlCommand("insert into [users](id,phone_number,email,password,cust_active,vendor_active,cust_name,cust_address,cust_latitude,cust_longitude,Created_at) Values (@id,@phone_number,@email,@password,@cust_active,@vendor_active,@cust_name,@cust_address,@cust_latitude,@cust_longitude,@Created_at)", conn);
            // field utama
            cmd.Parameters.AddWithValue("@id", newid);
            cmd.Parameters.AddWithValue("@phone_number", txtPhone.Text);
            cmd.Parameters.AddWithValue("@email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@password", txtPassword.Text); 
            cmd.Parameters.AddWithValue("@cust_active", cekbCostomer.Checked);
            cmd.Parameters.AddWithValue("@vendor_active", cekbVendor.Checked);

            // Field Customer
            cmd.Parameters.AddWithValue("@cust_name", txtNameCustomer.Text);
            cmd.Parameters.AddWithValue("@cust_address", txtAddressCustomer.Text);
            cmd.Parameters.AddWithValue("@cust_latitude", string.IsNullOrWhiteSpace(txtLatitudeCustomer.Text) ? (object)DBNull.Value : decimal.Parse(txtLatitudeCustomer.Text));
            cmd.Parameters.AddWithValue("@cust_longitude", string.IsNullOrWhiteSpace(txtLongitudeCustomer.Text) ? (object)DBNull.Value : decimal.Parse(txtLongitudeCustomer.Text));

            // Field Vendor
            cmd.Parameters.AddWithValue("@vendor_name", txtNameVendor.Text);
            cmd.Parameters.AddWithValue("@vendor_address", txtAddressVendor.Text);
            cmd.Parameters.AddWithValue("@vendor_latitude", string.IsNullOrWhiteSpace(txtLatitudeVendor.Text) ? (object)DBNull.Value : decimal.Parse(txtLatitudeVendor.Text));
            cmd.Parameters.AddWithValue("@vendor_longitude", string.IsNullOrWhiteSpace(txtLongitudeVendor.Text) ? (object)DBNull.Value : decimal.Parse(txtLongitudeVendor.Text));

            cmd.Parameters.AddWithValue("@Created_at", DateTime.Now);
            cmd.ExecuteNonQuery();

            conn.Close();
            MessageBox.Show("Pendaftaran berhasil!");

            this.Hide();
            new Form1().Show();
        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z0-9]+$";
            return Regex.IsMatch(email, pattern);
        }

        private bool IsValidPassword(string password)
        {
            if (password.Length < 8) return false;
            if (!password.Any(char.IsUpper)) return false;
            if (!password.Any(char.IsLower)) return false;
            if (!password.Any(char.IsDigit)) return false;
            return true;
        }
        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void txtLatitudeCustomer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLatitudeCustomer.Text.Contains("-") || txtLatitudeCustomer.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLatitudeCustomer.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLongitudeCustomer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLongitudeCustomer.Text.Contains("-") || txtLongitudeCustomer.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLongitudeCustomer.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLatitudeVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLatitudeVendor.Text.Contains("-") || txtLatitudeVendor.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLatitudeVendor.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLongitudeVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLongitudeVendor.Text.Contains("-") || txtLongitudeVendor.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLongitudeVendor.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
        }
    }
}
