﻿using System;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace GrocerSeeker
{
    public partial class FormProfile : Form
    {
        private SqlCommand cmd;
        private SqlDataReader rd;
        private int userID;
        private bool isInitializing = true;

        private string userName;
        private string loginAs;

        Koneksi Konn = new Koneksi();

        public FormProfile(int userID,string userName,string loginAs)
        {
            InitializeComponent();

            this.userID = userID;
            this.userName = userName;
            this.loginAs = loginAs;

            this.Text = "GrocerSeeker";

        }

        private void centerLabel()
        {
            MessageProfile.Left = (this.ClientSize.Width - MessageProfile.Width) / 2;
        }

        void formawal()
        {
            btnEdit.Enabled = true;
            txtPhone.Enabled = false;
            txtEmail.Enabled = false;
            cekbCostomer.Enabled = false;
            cekbVendor.Enabled = false;
            gbCustomer.Enabled = false;
            gbVendor.Enabled = false;

            MessageProfile.Visible = false;
            btnSave.Visible = false;
            btnDiscard.Visible = false;
        }

        void loadprofile()
        {
            if (userID <= 0)
            {
                MessageBox.Show("User ID tidak valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SqlConnection conn = Konn.GetConn();
            conn.Open();
            cmd = new SqlCommand("Select * from [users] Where id = @id", conn);
            cmd.Parameters.AddWithValue("@id", userID);
            rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                txtPhone.Text = rd["phone_number"].ToString();
                txtEmail.Text = rd["email"].ToString();
                cekbCostomer.Checked = Convert.ToInt16(rd["cust_active"]) == 1;
                cekbVendor.Checked = Convert.ToInt16(rd["vendor_active"]) == 1;

                if (loginAs == "Customer" && !cekbCostomer.Checked)
                {
                    MessageBox.Show("Akses Anda dibatasi. Kembali ke halaman login.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.Hide();
                    new Form1().Show();
                    return;
                } 
                else if (loginAs == "Vendor" && !cekbVendor.Checked)
                {
                    MessageBox.Show("Akses Anda dibatasi. Kembali ke halaman login.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.Hide();
                    new Form1().Show();
                    return;
                }

                txtNameCustomer.Text = rd["cust_name"].ToString();
                txtAddressCustomer.Text = rd["cust_address"].ToString();
                txtLatitudeCustomer.Text = rd["cust_latitude"].ToString();
                txtLongitudeCustomer.Text = rd["cust_longitude"].ToString();

                txtNameVendor.Text = rd["vendor_name"].ToString();
                txtAddressVendor.Text = rd["vendor_address"].ToString();
                txtLatitudeVendor.Text = rd["vendor_latitude"].ToString();
                txtLongitudeVendor.Text = rd["vendor_longitude"].ToString();
            }
            else
            {
                MessageBox.Show("Data dengan user ID ini tidak ditemukan");
            }

            rd.Close();
            conn.Close();
        }


        private void FormProfile_Load(object sender, EventArgs e)
        {
            isInitializing = true; 
            formawal();
            loadprofile();
            isInitializing = false; 
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            btnEdit.Enabled = false;

            txtEmail.Enabled = true;
            cekbCostomer.Enabled = true;
            cekbVendor.Enabled = true;

            gbCustomer.Enabled = cekbCostomer.Checked;
            gbVendor.Enabled = cekbVendor.Checked;

            btnSave.Visible = true;
            btnDiscard.Visible = true;
        }

        private void cekbCostomer_CheckedChanged(object sender, EventArgs e)
        {
            if (isInitializing) return; 
            gbCustomer.Enabled = cekbCostomer.Checked;
        }

        private void cekbVendor_CheckedChanged(object sender, EventArgs e)
        {
            if (isInitializing) return;
            gbVendor.Enabled = cekbVendor.Checked;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                MessageProfile.Text = "Harap isi Email terlebih dahulu.";
                centerLabel();
                MessageProfile.Visible = true;
                return;
            }

            if (!cekbCostomer.Checked && !cekbVendor.Checked)
            {
                MessageProfile.Text = "Harap pilih minimal satu role.";
                centerLabel();
                MessageProfile.Visible = true;
                return;
            }

            if (cekbCostomer.Checked)
            {
                if (string.IsNullOrEmpty(txtNameCustomer.Text) || string.IsNullOrEmpty(txtAddressCustomer.Text) ||
                    string.IsNullOrEmpty(txtLatitudeCustomer.Text) || string.IsNullOrEmpty(txtLongitudeCustomer.Text))
                {
                    MessageProfile.Text = "Harap isi semua field untuk Customer Detail.";
                    centerLabel();
                    MessageProfile.Visible = true;
                    return;
                }
            }
            if (!IsValidEmail(txtEmail.Text))
            {
                MessageProfile.Text = "Format email yang Anda masukkan tidak valid";
                centerLabel();
                MessageProfile.Visible = true;
                return;
            }

            if (cekbVendor.Checked)
            {
                if (string.IsNullOrEmpty(txtNameVendor.Text) || string.IsNullOrEmpty(txtAddressVendor.Text) ||
                    string.IsNullOrEmpty(txtLatitudeVendor.Text) || string.IsNullOrEmpty(txtLongitudeVendor.Text))
                {
                    MessageProfile.Text = "Harap isi semua field untuk Vendor Detail.";
                    centerLabel();
                    MessageProfile.Visible = true;
                    return;
                }
            }

            SqlConnection conn = Konn.GetConn();
            conn.Open();
            cmd = new SqlCommand("UPDATE [users] SET email = @Email, cust_active = @CustActive, vendor_active = @VendorActive, cust_name = @CustName, cust_address = @CustAddress, cust_latitude = @CustLatitude, cust_longitude = @CustLongitude, vendor_name = @VendorName, vendor_address = @VendorAddress, vendor_latitude = @VendorLatitude, vendor_longitude = @VendorLongitude, updated_at = @UpdatedAt WHERE id = @Id", conn);
            cmd.Parameters.AddWithValue("@Id", userID);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@CustActive", cekbCostomer.Checked);
            cmd.Parameters.AddWithValue("@VendorActive", cekbVendor.Checked);
            cmd.Parameters.AddWithValue("@CustName", txtNameCustomer.Text);
            cmd.Parameters.AddWithValue("@CustAddress", txtAddressCustomer.Text);
            cmd.Parameters.AddWithValue("@CustLatitude", string.IsNullOrWhiteSpace(txtLatitudeCustomer.Text) ? (object)DBNull.Value : decimal.Parse(txtLatitudeCustomer.Text));
            cmd.Parameters.AddWithValue("@CustLongitude", string.IsNullOrWhiteSpace(txtLongitudeCustomer.Text) ? (object)DBNull.Value : decimal.Parse(txtLongitudeCustomer.Text));
            cmd.Parameters.AddWithValue("@VendorName", txtNameVendor.Text);
            cmd.Parameters.AddWithValue("@VendorAddress", txtAddressVendor.Text);
            cmd.Parameters.AddWithValue("@VendorLatitude", string.IsNullOrWhiteSpace(txtLatitudeVendor.Text) ? (object)DBNull.Value : decimal.Parse(txtLatitudeVendor.Text));
            cmd.Parameters.AddWithValue("@VendorLongitude", string.IsNullOrWhiteSpace(txtLongitudeVendor.Text) ? (object)DBNull.Value : decimal.Parse(txtLongitudeVendor.Text));
            cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.Now);

            cmd.ExecuteNonQuery();

            if (!cekbVendor.Checked)
            {
                cmd = new SqlCommand("Update [products] set is_active = 0 Where vendor_id = @vendor_id", conn);
                cmd.Parameters.AddWithValue("@vendor_id", userID);
                cmd.ExecuteNonQuery();
            }
            else if (!cekbCostomer.Checked)
            {
                cmd = new SqlCommand("update [transactions] set status = @status Where customer_id = @customer_id", conn);
                cmd.Parameters.AddWithValue("@status", "canceled");
                cmd.Parameters.AddWithValue("@customer_id", userID);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Update profil berhasil!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            formawal();
            loadprofile();
        }

        private void btnDiscard_Click_1(object sender, EventArgs e)
        {
            isInitializing = true;
            formawal();
            loadprofile();
            isInitializing = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var mainForm = new MainForm(userID, userName, loginAs);
            mainForm.ShowDialog();
            this.Close();


        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z0-9]+$";
            return Regex.IsMatch(email, pattern);
        }

        private void txtLatitudeCustomer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLatitudeCustomer.Text.Contains("-") || txtLatitudeCustomer.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLatitudeCustomer.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLongitudeCustomer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLongitudeCustomer.Text.Contains("-") || txtLongitudeCustomer.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLongitudeCustomer.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLatitudeVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLatitudeVendor.Text.Contains("-") || txtLatitudeVendor.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLatitudeVendor.Text.Contains(","))
            {
                e.Handled = true;
            }
        }

        private void txtLongitudeVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '-' && e.KeyChar != ',' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
            if (e.KeyChar == '-' && (txtLongitudeVendor.Text.Contains("-") || txtLongitudeVendor.SelectionStart != 0))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && txtLongitudeVendor.Text.Contains(","))
            {
                e.Handled = true;
            }
        }
    }
}
