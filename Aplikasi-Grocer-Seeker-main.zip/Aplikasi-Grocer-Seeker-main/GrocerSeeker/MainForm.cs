﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GrocerSeeker
{
    public partial class MainForm : Form
    {
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;

        Koneksi Konn = new Koneksi();

        private string userName;
        private string loginAs;
        private int userID;

        public MainForm(int userID, string userName,string loginAs)
        {
            InitializeComponent();

            this.userID = userID;

            this.userName = userName;
            this.loginAs = loginAs;

            this.Text = "GrocerSeeker";

        }

        void munculdata()
        {
           if(loginAs == "Customer")
            {
                lblName.Text = userName;
                lblLoginAs.Text = loginAs;
            }
           else if(loginAs == "Vendor")
            {
                lblName.Text = userName;
                lblLoginAs.Text = loginAs;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormProduct(userID,userName,loginAs).Show();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormProfile(userID,userName,loginAs).Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form1().Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            munculdata();
        }

        private void btnTransaction_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormTransaction(userID,userName,loginAs).Show();
        }
    }
}
