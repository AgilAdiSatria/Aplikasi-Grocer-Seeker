﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace GrocerSeeker
{
    public partial class FormTransaction : Form
    {
        private SqlCommand cmd;
        private SqlDataReader rd;
        private DataSet ds;
        private SqlDataAdapter da;

        private int userID;
        private string loginAs;
        private string userName;

        Koneksi Konn = new Koneksi();

        public FormTransaction(int userID,string userName,string loginAs)
        {
            InitializeComponent();

            this.userID = userID;
            this.loginAs = loginAs;
            this.userName = userName;

            this.Text = "GrocerSeeker";

        }

        void loadbutton()
        {
            if(loginAs == "Customer")
            {
                btnApprove.Visible = false;
                btnDecline.Visible = false;
            }
            else if(loginAs == "Vendor")
            {
                btnCencel.Visible = false;
            }
        }

        void LoadDatagridViewPending()
        {
            if(loginAs == "Customer")
            {
                SqlConnection conn = Konn.GetConn();
                conn.Open();

                cmd = new SqlCommand("Select t.id,p.product_name As product_name,u.vendor_name As vendor_name,t.quantity,p.price_per_unit As price_per_unit,t.total_price,t.delivery_cost,t.status From [transactions] t INNER JOIN [products] p ON t.product_id = p.id INNER JOIN [users]u ON t.vendor_id = u.id Where t.status = 'pending' AND t.customer_id = @customer_id", conn);
                cmd.Parameters.AddWithValue("@customer_id",userID);

                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds, "transactions");

                dgPending.DataSource = ds;
                dgPending.DataMember = "transactions";

                dgPending.Columns["id"].Visible = false;

                conn.Close();
            }
            else if (loginAs == "Vendor")
            {
                SqlConnection conn = Konn.GetConn();
                conn.Open();

                cmd = new SqlCommand("Select t.id,p.product_name As product_name,u.cust_name As customer_name,t.quantity,p.price_per_unit As price_per_unit,t.total_price,t.delivery_cost,t.status From [transactions] t INNER JOIN [products] p ON t.product_id = p.id INNER JOIN [users]u ON t.customer_id = u.id Where t.status = 'pending' AND t.vendor_id = @vendor_id", conn);
                cmd.Parameters.AddWithValue("@vendor_id", userID);

                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds, "transactions");

                dgPending.DataSource = ds;
                dgPending.DataMember = "transactions";

                dgPending.Columns["id"].Visible = false;

                conn.Close();
            }
        }

        void LoadDatagridviewHistory()
        {
            if(loginAs == "Customer")
            {
                SqlConnection conn = Konn.GetConn();
                conn.Open();

                cmd = new SqlCommand("Select p.product_name As product_name,u.vendor_name As vendor_name,t.quantity,p.price_per_unit As price_per_unit,t.total_price,t.delivery_cost,t.status From [transactions] t INNER JOIN [products] p ON t.product_id = p.id INNER JOIN [users]u ON t.vendor_id = u.id Where t.status IN ('success','abort','canceled') AND t.customer_id = @customer_id", conn);
                cmd.Parameters.AddWithValue("@customer_id", userID);

                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds, "transactions");

                dgHistory.DataSource = ds;
                dgHistory.DataMember = "transactions";

                conn.Close();

            }
            else if(loginAs == "Vendor")
            {
                SqlConnection conn = Konn.GetConn();
                conn.Open();

                cmd = new SqlCommand("Select p.product_name As product_name,u.cust_name As customer_name,t.quantity,p.price_per_unit As price_per_unit,t.total_price,t.delivery_cost,t.status From [transactions] t INNER JOIN [products] p ON t.product_id = p.id INNER JOIN [users]u ON t.customer_id = u.id Where t.status IN ('success','abort','canceled') AND t.vendor_id = @vendor_id", conn);
                cmd.Parameters.AddWithValue("@vendor_id", userID);

                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds, "transactions");

                dgHistory.DataSource = ds;
                dgHistory.DataMember = "transactions";

                conn.Close();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FormTransaction_Load(object sender, EventArgs e)
        {
            loadbutton();
            LoadDatagridViewPending();
            LoadDatagridviewHistory();
        }

        private void gbHistory_Enter(object sender, EventArgs e)
        {

        }

        private void dgPending_SelectionChanged(object sender, EventArgs e)
        {
            if (loginAs == "Customer")
            {
                if (dgPending.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedrow = dgPending.SelectedRows[0];

                    string product_name = selectedrow.Cells["product_name"].Value != DBNull.Value ? selectedrow.Cells["product_name"].Value.ToString() : string.Empty;
                    string vendor_name = selectedrow.Cells["vendor_name"].Value != DBNull.Value ? selectedrow.Cells["vendor_name"].Value.ToString() : string.Empty;
                    decimal qty = selectedrow.Cells["quantity"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["quantity"].Value) : 0;
                    decimal price_per_unit = selectedrow.Cells["price_per_unit"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["price_per_unit"].Value) : 0;
                    decimal total_price = selectedrow.Cells["total_price"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["total_price"].Value) : 0;
                    decimal delivery_cost = selectedrow.Cells["delivery_cost"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["delivery_cost"].Value) : 0;

                    lblProduct_name.Text = product_name;
                    lblUser_name.Text = vendor_name;
                    lblQuantity.Text = qty.ToString();
                    lblprice.Text = price_per_unit.ToString();
                    lblTotal.Text = total_price.ToString();
                    lblDelivery.Text = delivery_cost.ToString();
                }
            }
            else if (loginAs == "Vendor")
            {
                if (dgPending.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedrow = dgPending.SelectedRows[0];

                    string product_name = selectedrow.Cells["product_name"].Value != DBNull.Value ? selectedrow.Cells["product_name"].Value.ToString() : string.Empty;
                    string customer_name = selectedrow.Cells["customer_name"].Value != DBNull.Value ? selectedrow.Cells["customer_name"].Value.ToString() : string.Empty;
                    decimal qty = selectedrow.Cells["quantity"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["quantity"].Value) : 0;
                    decimal price_per_unit = selectedrow.Cells["price_per_unit"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["price_per_unit"].Value) : 0;
                    decimal total_price = selectedrow.Cells["total_price"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["total_price"].Value) : 0;
                    decimal delivery_cost = selectedrow.Cells["delivery_cost"].Value != DBNull.Value ? Convert.ToDecimal(selectedrow.Cells["delivery_cost"].Value) : 0;

                    lblProduct_name.Text = product_name;
                    lblUser_name.Text = customer_name;
                    lblQuantity.Text = qty.ToString();
                    lblprice.Text = price_per_unit.ToString();
                    lblTotal.Text = total_price.ToString();
                    lblDelivery.Text = delivery_cost.ToString();
                }
            }
        }


        private void btnCencel_Click(object sender, EventArgs e)
        {
            if (dgPending.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Apakah Anda yakin ingin membatalkan transaksi ini?", "Konfirmasi Pembatalan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    DataGridViewRow selectedRow = dgPending.SelectedRows[0];

                    string product_name = selectedRow.Cells["product_name"].Value.ToString();
                    string transaction_id = selectedRow.Cells["id"].Value.ToString();
                    string vendor_name = selectedRow.Cells["vendor_name"].Value.ToString();
                    decimal qty = Convert.ToDecimal(selectedRow.Cells["quantity"].Value);
                    decimal price_per_unit = Convert.ToDecimal(selectedRow.Cells["price_per_unit"].Value);
                    decimal total_price = Convert.ToDecimal(selectedRow.Cells["total_price"].Value);
                    decimal delivery_cost = Convert.ToDecimal(selectedRow.Cells["delivery_cost"].Value);

                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("Update [transactions] set status = @status Where id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", transaction_id);
                    cmd.Parameters.AddWithValue("@status", "canceled");
                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand("Update [products] set unit_stock = unit_stock + @unit_stock Where product_name = @product_name", conn);
                    cmd.Parameters.AddWithValue("@product_name", product_name);
                    cmd.Parameters.AddWithValue("@unit_stock", qty);
                    cmd.ExecuteNonQuery();

                    conn.Close();

                    LoadDatagridviewHistory();
                    LoadDatagridViewPending();
                }
            }
            else
            {
                MessageBox.Show("Harap pilih data yang ingin dibatalkan", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (dgPending.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Apakah Anda yakin ingin menyetujui transaksi ini?", "Konfirmasi Pembatalan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    DataGridViewRow selectedrow = dgPending.SelectedRows[0];

                    string product_name = selectedrow.Cells["product_name"].Value.ToString();
                    string transaction_id = selectedrow.Cells["id"].Value.ToString();
                    string customer_name = selectedrow.Cells["customer_name"].Value.ToString();
                    decimal qty = Convert.ToDecimal(selectedrow.Cells["quantity"].Value);
                    decimal price_per_unit = Convert.ToDecimal(selectedrow.Cells["price_per_unit"].Value);
                    decimal total_price = Convert.ToDecimal(selectedrow.Cells["total_price"].Value);
                    decimal delivery_cost = Convert.ToDecimal(selectedrow.Cells["delivery_cost"].Value);

                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("Update [transactions] set status = @status Where id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", transaction_id);
                    cmd.Parameters.AddWithValue("@status", "success");
                    cmd.ExecuteNonQuery();

                    conn.Close();

                    LoadDatagridviewHistory();
                    LoadDatagridViewPending();
                }
            }
            else
            {
                MessageBox.Show("Harap pilih data yang ingin disetujui ", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }


        }

        private void btnDecline_Click(object sender, EventArgs e)
        {

            if (dgPending.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Apakah Anda yakin ingin menyetujui transaksi ini?", "Konfirmasi Pembatalan", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    DataGridViewRow selectedrow = dgPending.SelectedRows[0];

                    string product_name = selectedrow.Cells["product_name"].Value.ToString();
                    string transaction_id = selectedrow.Cells["id"].Value.ToString();
                    string customer_name = selectedrow.Cells["customer_name"].Value.ToString();
                    decimal qty = Convert.ToDecimal(selectedrow.Cells["quantity"].Value);
                    decimal price_per_unit = Convert.ToDecimal(selectedrow.Cells["price_per_unit"].Value);
                    decimal total_price = Convert.ToDecimal(selectedrow.Cells["total_price"].Value);
                    decimal delivery_cost = Convert.ToDecimal(selectedrow.Cells["delivery_cost"].Value);

                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("Update [transactions] set status = @status Where id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", transaction_id);
                    cmd.Parameters.AddWithValue("@status", "abort");
                    cmd.ExecuteNonQuery();

                    conn.Close();

                    LoadDatagridviewHistory();
                    LoadDatagridViewPending();
                }
            }
            else
            {
                MessageBox.Show("Harap pilih data yang ingin ditolok ", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm(userID,userName,loginAs).Show();
        }

        private void dgPending_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dgPending.Rows[e.RowIndex].Selected = true;
            }

        }

        private void dgHistory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dgHistory.Rows[e.RowIndex].Selected = true;
            }

        }
    }
}
