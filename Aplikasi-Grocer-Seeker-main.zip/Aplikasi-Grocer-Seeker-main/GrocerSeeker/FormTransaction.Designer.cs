﻿namespace GrocerSeeker
{
    partial class FormTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbHistory = new System.Windows.Forms.GroupBox();
            this.dgHistory = new System.Windows.Forms.DataGridView();
            this.gbPending = new System.Windows.Forms.GroupBox();
            this.dgPending = new System.Windows.Forms.DataGridView();
            this.gbDetails = new System.Windows.Forms.GroupBox();
            this.btnCencel = new System.Windows.Forms.Button();
            this.btnDecline = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.lblDelivery = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblProduct_name = new System.Windows.Forms.Label();
            this.lblUser_name = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbHistory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgHistory)).BeginInit();
            this.gbPending.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPending)).BeginInit();
            this.gbDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbHistory
            // 
            this.gbHistory.Controls.Add(this.dgHistory);
            this.gbHistory.Location = new System.Drawing.Point(12, 48);
            this.gbHistory.Name = "gbHistory";
            this.gbHistory.Size = new System.Drawing.Size(772, 186);
            this.gbHistory.TabIndex = 0;
            this.gbHistory.TabStop = false;
            this.gbHistory.Text = "History";
            this.gbHistory.Enter += new System.EventHandler(this.gbHistory_Enter);
            // 
            // dgHistory
            // 
            this.dgHistory.AllowUserToAddRows = false;
            this.dgHistory.AllowUserToDeleteRows = false;
            this.dgHistory.BackgroundColor = System.Drawing.Color.White;
            this.dgHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgHistory.Location = new System.Drawing.Point(7, 20);
            this.dgHistory.Name = "dgHistory";
            this.dgHistory.ReadOnly = true;
            this.dgHistory.Size = new System.Drawing.Size(759, 154);
            this.dgHistory.TabIndex = 0;
            this.dgHistory.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgHistory_CellClick);
            // 
            // gbPending
            // 
            this.gbPending.Controls.Add(this.dgPending);
            this.gbPending.Location = new System.Drawing.Point(12, 240);
            this.gbPending.Name = "gbPending";
            this.gbPending.Size = new System.Drawing.Size(772, 151);
            this.gbPending.TabIndex = 1;
            this.gbPending.TabStop = false;
            this.gbPending.Text = "Pending";
            // 
            // dgPending
            // 
            this.dgPending.AllowUserToAddRows = false;
            this.dgPending.AllowUserToDeleteRows = false;
            this.dgPending.BackgroundColor = System.Drawing.Color.White;
            this.dgPending.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPending.Location = new System.Drawing.Point(7, 19);
            this.dgPending.Name = "dgPending";
            this.dgPending.ReadOnly = true;
            this.dgPending.Size = new System.Drawing.Size(759, 126);
            this.dgPending.TabIndex = 0;
            this.dgPending.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPending_CellClick);
            this.dgPending.SelectionChanged += new System.EventHandler(this.dgPending_SelectionChanged);
            // 
            // gbDetails
            // 
            this.gbDetails.Controls.Add(this.btnCencel);
            this.gbDetails.Controls.Add(this.btnDecline);
            this.gbDetails.Controls.Add(this.btnApprove);
            this.gbDetails.Controls.Add(this.lblDelivery);
            this.gbDetails.Controls.Add(this.lblTotal);
            this.gbDetails.Controls.Add(this.lblprice);
            this.gbDetails.Controls.Add(this.lblQuantity);
            this.gbDetails.Controls.Add(this.lblProduct_name);
            this.gbDetails.Controls.Add(this.lblUser_name);
            this.gbDetails.Controls.Add(this.label6);
            this.gbDetails.Controls.Add(this.label5);
            this.gbDetails.Controls.Add(this.label4);
            this.gbDetails.Controls.Add(this.label3);
            this.gbDetails.Controls.Add(this.name);
            this.gbDetails.Controls.Add(this.label1);
            this.gbDetails.Location = new System.Drawing.Point(123, 397);
            this.gbDetails.Name = "gbDetails";
            this.gbDetails.Size = new System.Drawing.Size(534, 181);
            this.gbDetails.TabIndex = 2;
            this.gbDetails.TabStop = false;
            this.gbDetails.Text = "Details";
            // 
            // btnCencel
            // 
            this.btnCencel.Location = new System.Drawing.Point(414, 68);
            this.btnCencel.Name = "btnCencel";
            this.btnCencel.Size = new System.Drawing.Size(96, 49);
            this.btnCencel.TabIndex = 14;
            this.btnCencel.Text = "Cancel\r\nTransaction";
            this.btnCencel.UseVisualStyleBackColor = true;
            this.btnCencel.Click += new System.EventHandler(this.btnCencel_Click);
            // 
            // btnDecline
            // 
            this.btnDecline.Location = new System.Drawing.Point(414, 123);
            this.btnDecline.Name = "btnDecline";
            this.btnDecline.Size = new System.Drawing.Size(96, 32);
            this.btnDecline.TabIndex = 13;
            this.btnDecline.Text = "Declline";
            this.btnDecline.UseVisualStyleBackColor = true;
            this.btnDecline.Click += new System.EventHandler(this.btnDecline_Click);
            // 
            // btnApprove
            // 
            this.btnApprove.Location = new System.Drawing.Point(414, 32);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(96, 32);
            this.btnApprove.TabIndex = 12;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = true;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // lblDelivery
            // 
            this.lblDelivery.AutoSize = true;
            this.lblDelivery.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelivery.Location = new System.Drawing.Point(324, 133);
            this.lblDelivery.Name = "lblDelivery";
            this.lblDelivery.Size = new System.Drawing.Size(25, 13);
            this.lblDelivery.TabIndex = 11;
            this.lblDelivery.Text = "0.0";
            this.lblDelivery.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(324, 99);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(25, 13);
            this.lblTotal.TabIndex = 10;
            this.lblTotal.Text = "0.0";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprice.Location = new System.Drawing.Point(108, 133);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(25, 13);
            this.lblprice.TabIndex = 9;
            this.lblprice.Text = "0.0";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(108, 99);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(25, 13);
            this.lblQuantity.TabIndex = 8;
            this.lblQuantity.Text = "0.0";
            // 
            // lblProduct_name
            // 
            this.lblProduct_name.AutoSize = true;
            this.lblProduct_name.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct_name.Location = new System.Drawing.Point(108, 37);
            this.lblProduct_name.Name = "lblProduct_name";
            this.lblProduct_name.Size = new System.Drawing.Size(84, 13);
            this.lblProduct_name.TabIndex = 7;
            this.lblProduct_name.Text = "Name Product";
            // 
            // lblUser_name
            // 
            this.lblUser_name.AutoSize = true;
            this.lblUser_name.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser_name.Location = new System.Drawing.Point(108, 68);
            this.lblUser_name.Name = "lblUser_name";
            this.lblUser_name.Size = new System.Drawing.Size(38, 13);
            this.lblUser_name.TabIndex = 6;
            this.lblUser_name.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(227, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Delivery Cost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(227, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Total Transaction";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Price Per Unit";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantity";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(20, 68);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(82, 13);
            this.name.TabIndex = 1;
            this.name.Text = "Customer Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(340, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "Transaction";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // FormTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 612);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gbDetails);
            this.Controls.Add(this.gbPending);
            this.Controls.Add(this.gbHistory);
            this.Name = "FormTransaction";
            this.Text = "FormTransaction";
            this.Load += new System.EventHandler(this.FormTransaction_Load);
            this.gbHistory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgHistory)).EndInit();
            this.gbPending.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgPending)).EndInit();
            this.gbDetails.ResumeLayout(false);
            this.gbDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbHistory;
        private System.Windows.Forms.DataGridView dgHistory;
        private System.Windows.Forms.GroupBox gbPending;
        private System.Windows.Forms.DataGridView dgPending;
        private System.Windows.Forms.GroupBox gbDetails;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblProduct_name;
        private System.Windows.Forms.Label lblUser_name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label lblDelivery;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnCencel;
        private System.Windows.Forms.Button btnDecline;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Label label2;
    }
}