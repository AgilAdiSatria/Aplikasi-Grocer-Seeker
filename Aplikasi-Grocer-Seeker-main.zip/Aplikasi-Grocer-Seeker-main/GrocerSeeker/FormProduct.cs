﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GrocerSeeker
{
    public partial class FormProduct : Form
    {
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private DataSet ds;

        private int UserID;
        private string UserName;
        private string loginAs;

        private bool isEditMode = false;

        Koneksi Konn = new Koneksi();

        public FormProduct(int UserID, string Username, string loginAs)
        {
            InitializeComponent();
            this.UserID = UserID;
            this.UserName = Username;
            this.loginAs = loginAs;

            this.Text = "GrocerSeeker";

        }

        private void centerLabel()
        {
            MessageProduct.Left = (this.ClientSize.Width - MessageProduct.Width) / 2;
        }

        void Loadbutton()
        {
            btnAddItem.Enabled = true;
            btnEditItem.Enabled = true;
            btnDeleteItem.Enabled = true;
        }

        void Clear()
        {
            txtNameProduct.Clear();
            cbCategories.SelectedIndex = -1;
            cbStatus.SelectedIndex = -1;
            rbCountable.Checked = false;
            rbMeasurable.Checked = false;
            nuPrice.Value = 0;
            nuQty.Value = 0;
            lblTotalPrice.Text = "0,0";
            lblDelivery.Text = "0,0";
            nuStock.Value = 0;
            isEditMode = false;
            btnSave.Tag = null;

            if (dgProduct.SelectedRows.Count > 0)
            {
                dgProduct.ClearSelection();
            }
        }


        void LoadComboBox1()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();

            DataTable dt = new DataTable();
            cmd = new SqlCommand("SELECT id, name FROM [Categories]", conn);
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            cbCategories.DataSource = dt;
            cbCategories.ValueMember = "id";
            cbCategories.DisplayMember = "name";

            cbCategories.SelectedIndex = -1;

            conn.Close();
        }

        void LoadComboBox2()
        {
            cbStatus.Items.Add("active");
            cbStatus.Items.Add("inactive");
        }

        void formproductLoad()
        {
            if (loginAs == "Customer")
            {
                btnAddItem.Visible = false;
                btnEditItem.Visible = false;
                btnDeleteItem.Visible = false;
                gbDetailProduct.Enabled = false;
                label5.Visible = false;
                cbStatus.Visible = false;
                btnSave.Visible = false;
                btnCancel.Visible = false;
                btnBuy.Visible = false;
                btnClear.Visible = false;
                gbTrasactionDetail.Enabled = false;
            }
            else if (loginAs == "Vendor")
            {
                gbTrasactionDetail.Visible = false;
            }
            else
            {
                MessageBox.Show("Peran tidak Dikenal");
            }
        }

        private void UpdateTransactionTotal()
        {
            decimal price = nuPrice.Value;
            decimal quantity = nuQty.Value;

            decimal total = price * quantity;
            lblTotalPrice.Text = total.ToString();
        }

        private double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
        {
            const double R = 6371.0;
            double latRad1 = lat1 * (Math.PI / 180);
            double latRad2 = lat2 * (Math.PI / 180);
            double deltaLat = (lat2 - lat1) * (Math.PI / 180);
            double deltaLon = (lon2 - lon1) * (Math.PI / 180);

            double a = Math.Sin(deltaLat / 2) * Math.Sin(deltaLat / 2) +
                       Math.Cos(latRad1) * Math.Cos(latRad2) *
                       Math.Sin(deltaLon / 2) * Math.Sin(deltaLon / 2);
            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            double distance = R * c; 
            return distance;
        }

        private decimal CalculateDeliveryCost(double distanceKm)
        {
            double roundedDistance = Math.Ceiling(distanceKm / 100) * 100;
            decimal cost = (decimal)(roundedDistance / 100) * 15000;
            lblDelivery.Text = cost.ToString("N0");
            return cost;
        }


        void LoadDatagridView()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();

            if (loginAs == "Vendor")
            {
                cmd = new SqlCommand("SELECT p.id, p.product_name, c.name AS category_name, p.unit_type, p.price_per_unit, p.unit_stock, p.is_active FROM [products] p INNER JOIN [categories] c ON p.category_id = c.id WHERE p.vendor_id = @vendor_id", conn);
                cmd.Parameters.AddWithValue("@vendor_id", UserID);

                ds = new DataSet();
                da = new SqlDataAdapter(cmd);
                da.Fill(ds, "products");

                dgProduct.DataSource = ds;
                dgProduct.DataMember = "products";

                if (dgProduct.Columns.Contains("is_active"))
                {
                    DataGridViewCheckBoxColumn chkColumn = new DataGridViewCheckBoxColumn();
                    chkColumn.Name = "is_active";
                    chkColumn.HeaderText = "status";
                    chkColumn.DataPropertyName = "is_active";

                    dgProduct.Columns.Remove("is_active");

                    dgProduct.Columns.Add(chkColumn);
                }

                dgProduct.Columns["id"].Visible = false;

                conn.Close();
            }


            else if (loginAs == "Customer")
            {
                cmd = new SqlCommand("SELECT p.id, p.vendor_id, u.vendor_name AS vendor_name, p.product_name, c.name AS category_name, p.unit_type, p.price_per_unit, p.unit_stock FROM [products] p INNER JOIN [categories] c ON p.category_id = c.id INNER JOIN [users] u ON p.vendor_id = u.id Where p.is_active = 1 And p.unit_stock > 0", conn);

                ds = new DataSet();
                da = new SqlDataAdapter(cmd);
                da.Fill(ds, "products");

                dgProduct.DataSource = ds;
                dgProduct.DataMember = "products";

                dgProduct.Columns["id"].Visible = false;
                dgProduct.Columns["vendor_id"].Visible = false;


                conn.Close();
            }
        }



        private void FormProduct_Load(object sender, EventArgs e)
        {
            MessageProduct.Visible = false;
            formproductLoad();
            LoadDatagridView();
            LoadComboBox1();
            gbDetailProduct.Enabled = false;
            LoadComboBox2();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            isEditMode = false;
            gbDetailProduct.Enabled = true;
            btnAddItem.Enabled = false;
            btnEditItem.Enabled = false;
            btnDeleteItem.Enabled = false;
        }

        private void btnEditItem_Click(object sender, EventArgs e)
        {
            if (dgProduct.SelectedRows.Count > 0)
            {
                isEditMode = true;
                gbDetailProduct.Enabled = true;

                btnAddItem.Enabled = false;
                btnEditItem.Enabled = false;
                btnDeleteItem.Enabled = false;

                DataGridViewRow selectedRow = dgProduct.SelectedRows[0];
                int product_id = Convert.ToInt32(selectedRow.Cells["id"].Value);
                string product_name = selectedRow.Cells["product_name"].Value.ToString();
                string category_name = selectedRow.Cells["category_name"].Value.ToString();
                string unit_type = selectedRow.Cells["unit_type"].Value.ToString();
                bool isActive = Convert.ToBoolean(selectedRow.Cells["is_active"].Value);
                Decimal price = Convert.ToDecimal(selectedRow.Cells["price_per_unit"].Value);
                Decimal unit = Convert.ToDecimal(selectedRow.Cells["unit_stock"].Value);

                btnSave.Tag = product_id;

                txtNameProduct.Text = product_name;
                cbCategories.Text = category_name;

                if (unit_type.ToLower() == "countable")
                    rbCountable.Checked = true;
                else if (unit_type.ToLower() == "measurable")
                    rbMeasurable.Checked = true;

                cbStatus.SelectedItem = isActive ? "active" : "inactive";
                nuPrice.Value = price;
                nuStock.Value = unit;
            }
            else
            {
                MessageProduct.Text = "Harap Pilih Item yang Ingin Di Edit Terlebih Dahulu";
                centerLabel();
                MessageProduct.Visible = true;

            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();

            string unit_type = rbCountable.Checked ? "countable" : "measurable";
            int category_id = Convert.ToInt32(cbCategories.SelectedValue);
            int isActive = cbStatus.SelectedItem.ToString() == "active" ? 1 : 0;

            if (isEditMode)
            {
                if (btnSave.Tag != null)
                {
                    int product_id = (int)btnSave.Tag;

                    cmd = new SqlCommand("UPDATE [products] SET product_name = @product_name, category_id = @category_id, unit_type = @unit_type, price_per_unit = @price_per_unit, unit_stock = @unit_stock, is_active = @is_active WHERE id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", product_id);
                    cmd.Parameters.AddWithValue("@product_name", txtNameProduct.Text);
                    cmd.Parameters.AddWithValue("@category_id", category_id);
                    cmd.Parameters.AddWithValue("@unit_type", unit_type);
                    cmd.Parameters.AddWithValue("@price_per_unit", Convert.ToDecimal(nuPrice.Value));
                    cmd.Parameters.AddWithValue("@unit_stock", Convert.ToDecimal(nuStock.Value));
                    cmd.Parameters.AddWithValue("@is_active", isActive);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Data berhasil diedit");
                }
            }
            else
            {
                cmd = new SqlCommand("Select Isnull (Max(id),0) + 1 From [products]", conn);
                int newid = (int)cmd.ExecuteScalar();

                cmd = new SqlCommand("INSERT INTO [products](id, vendor_id, product_name, category_id, unit_type, price_per_unit, unit_stock, is_active) VALUES (@id, @vendor_id, @product_name, @category_id, @unit_type, @price_per_unit, @unit_stock, @is_active)", conn);
                cmd.Parameters.AddWithValue("@id", newid);
                cmd.Parameters.AddWithValue("@vendor_id", UserID);
                cmd.Parameters.AddWithValue("@product_name", txtNameProduct.Text);
                cmd.Parameters.AddWithValue("@category_id", category_id);
                cmd.Parameters.AddWithValue("@unit_type", unit_type);
                cmd.Parameters.AddWithValue("@price_per_unit", Convert.ToDecimal(nuPrice.Value));
                cmd.Parameters.AddWithValue("@unit_stock", Convert.ToDecimal(nuStock.Value));
                cmd.Parameters.AddWithValue("@is_active", isActive);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Data berhasil ditambahkan");
            }

            conn.Close();
            LoadDatagridView();
            Clear();
            Loadbutton();
            gbDetailProduct.Enabled = false;
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
            Loadbutton();
            gbDetailProduct.Enabled = false;
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (dgProduct.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedrow = dgProduct.SelectedRows[0];

                string product_name = selectedrow.Cells["product_name"].Value.ToString();

                if (MessageBox.Show("Apakah anda yakin ingin menghapus data ini", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("Delete [products] Where product_name = @product_name", conn);
                    cmd.Parameters.AddWithValue("@product_name", product_name);

                    cmd.ExecuteNonQuery();
                    LoadDatagridView();
                }
            }
            else
            {
                MessageProduct.Text = "Harap Pilih Item yang Ingin Di Hapus Terlebih Dahulu";
                centerLabel();
                MessageProduct.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void dgProduct_SelectionChanged(object sender, EventArgs e)
        {
            if (loginAs == "Customer")
            {
                if (dgProduct.SelectedRows.Count > 0)
                {
                    gbDetailProduct.Enabled = false;
                    btnAddItem.Enabled = false;
                    btnEditItem.Enabled = false;
                    btnDeleteItem.Enabled = false;
                    btnBuy.Visible = true;
                    btnClear.Visible = true;
                    gbTrasactionDetail.Enabled = true;

                    DataGridViewRow selectedRow = dgProduct.SelectedRows[0];
                    string product_name = selectedRow.Cells["product_name"].Value.ToString();
                    string category_name = selectedRow.Cells["category_name"].Value.ToString();
                    string unit_type = selectedRow.Cells["unit_type"].Value.ToString();
                    decimal price = Convert.ToDecimal(selectedRow.Cells["price_per_unit"].Value);
                    decimal unit = Convert.ToDecimal(selectedRow.Cells["unit_stock"].Value);
                    int vendor_id = Convert.ToInt32(selectedRow.Cells["vendor_id"].Value); 

                    txtNameProduct.Text = product_name;
                    cbCategories.Text = category_name;
                    nuPrice.Value = price;
                    nuStock.Value = unit;
                    nuQty.Value = 0;

                    if (unit_type.ToLower() == "countable")
                        rbCountable.Checked = true;
                    else if (unit_type.ToLower() == "measurable")
                        rbMeasurable.Checked = true;

                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("SELECT vendor_latitude, vendor_longitude FROM [users] WHERE id = @vendor_id", conn);
                    cmd.Parameters.AddWithValue("@vendor_id", vendor_id);
                    SqlDataReader vendorReader = cmd.ExecuteReader();
                    vendorReader.Read();
                    double vendor_lat = Convert.IsDBNull(vendorReader["vendor_latitude"]) ? 0.0 : Convert.ToDouble(vendorReader["vendor_latitude"]);
                    double vendor_lon = Convert.IsDBNull(vendorReader["vendor_longitude"]) ? 0.0 : Convert.ToDouble(vendorReader["vendor_longitude"]);
                    vendorReader.Close();

                    cmd = new SqlCommand("SELECT cust_latitude, cust_longitude FROM [users] WHERE id = @customer_id", conn);
                    cmd.Parameters.AddWithValue("@customer_id", UserID);
                    SqlDataReader customerReader = cmd.ExecuteReader();
                    customerReader.Read();
                    double customer_lat = Convert.IsDBNull(customerReader["cust_latitude"]) ? 0.0 : Convert.ToDouble(customerReader["cust_latitude"]);
                    double customer_lon = Convert.IsDBNull(customerReader["cust_longitude"]) ? 0.0 : Convert.ToDouble(customerReader["cust_longitude"]);
                    customerReader.Close();

                    conn.Close();

                    double distance = CalculateDistance(vendor_lat, vendor_lon, customer_lat, customer_lon);
                    decimal delivery_cost = CalculateDeliveryCost(distance);

                    lblDelivery.Text = delivery_cost.ToString("N0");
                }
            }
        }



        private void nuQty_ValueChanged(object sender, EventArgs e)
        {
            UpdateTransactionTotal();
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            if (nuQty.Value > 0)
            {
                DataGridViewRow selectedRow = dgProduct.SelectedRows[0];
                decimal qty = nuQty.Value;
                decimal unit_stock = Convert.ToDecimal(selectedRow.Cells["unit_stock"].Value);

                // Cek apakah jumlah qty melebihi stok
                if (qty > unit_stock)
                {
                    MessageProduct.Text = "Jumlah Pembelian Melebihi Stok Product";
                    centerLabel();
                    MessageProduct.Visible = true;
                    return; // Hentikan proses tanpa menampilkan konfirmasi
                }

                // Jika stok cukup, tampilkan konfirmasi pembelian
                if (MessageBox.Show("Apakah anda yakin ingin membeli item ini?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int product_id = Convert.ToInt32(selectedRow.Cells["id"].Value);
                    int vendor_id = Convert.ToInt32(selectedRow.Cells["vendor_id"].Value);
                    decimal price_per_unit = Convert.ToDecimal(selectedRow.Cells["price_per_unit"].Value);
                    decimal total_price = qty * price_per_unit;

                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("SELECT vendor_latitude, vendor_longitude, cust_latitude, cust_longitude FROM [users] WHERE id = @customer_id", conn);
                    cmd.Parameters.AddWithValue("@customer_id", UserID);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();

                    double vendor_lat = Convert.IsDBNull(reader["vendor_latitude"]) ? 0.0 : Convert.ToDouble(reader["vendor_latitude"]);
                    double vendor_lon = Convert.IsDBNull(reader["vendor_longitude"]) ? 0.0 : Convert.ToDouble(reader["vendor_longitude"]);
                    double customer_lat = Convert.IsDBNull(reader["cust_latitude"]) ? 0.0 : Convert.ToDouble(reader["cust_latitude"]);
                    double customer_lon = Convert.IsDBNull(reader["cust_longitude"]) ? 0.0 : Convert.ToDouble(reader["cust_longitude"]);

                    reader.Close();

                    double distance = CalculateDistance(vendor_lat, vendor_lon, customer_lat, customer_lon);
                    decimal delivery_cost = CalculateDeliveryCost(distance);

                    cmd = new SqlCommand("SELECT ISNULL(MAX(id), 0) + 1 FROM [transactions]", conn);
                    int newid = (int)cmd.ExecuteScalar();

                    SqlTransaction tr = conn.BeginTransaction();

                    cmd = new SqlCommand("INSERT INTO [transactions] ( vendor_id, customer_id, product_id, quantity, total_price, delivery_cost, status) " +
                        "VALUES ( @vendor_id, @customer_id, @product_id, @quantity, @total_price, @delivery_cost, @status)", conn);
                    cmd.Parameters.AddWithValue("@vendor_id", vendor_id);
                    cmd.Parameters.AddWithValue("@customer_id", UserID);
                    cmd.Parameters.AddWithValue("@product_id", product_id);
                    cmd.Parameters.AddWithValue("@quantity", qty);
                    cmd.Parameters.AddWithValue("@total_price", total_price);
                    cmd.Parameters.AddWithValue("@delivery_cost", delivery_cost);
                    cmd.Parameters.AddWithValue("@status", "pending");
                    cmd.Transaction = tr;

                    cmd.ExecuteNonQuery();

                    cmd = new SqlCommand("UPDATE [products] SET unit_stock = @unit_stock WHERE id = @product_id", conn);
                    cmd.Parameters.AddWithValue("@unit_stock", unit_stock - qty);
                    cmd.Parameters.AddWithValue("@product_id", product_id);
                    cmd.Transaction = tr;

                    cmd.ExecuteNonQuery();
                    tr.Commit();

                    conn.Close();
                    LoadDatagridView();

                    MessageBox.Show("Item yang anda pesan sudah dikirim ke Vendor. Harap tunggu persetujuan dari vendor.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Clear();
                    gbDetailProduct.Enabled = false;
                }
            }
            else
            {
                MessageProduct.Text = "Opps, Anda Belum Menentukan Jumlah Produk yang akan dibeli";
                centerLabel();
                MessageProduct.Visible = true;
            }
        }




        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm(UserID,UserName,loginAs).Show();
        }

        private void gbTrasactionDetail_Enter(object sender, EventArgs e)
        {

        }

        private void dgProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void dgProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dgProduct.Rows[e.RowIndex].Selected = true;
            }

        }
    }
}
