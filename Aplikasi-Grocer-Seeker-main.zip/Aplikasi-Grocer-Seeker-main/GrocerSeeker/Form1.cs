﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace GrocerSeeker
{
    public partial class Form1 : Form
    {
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;
        private DataTable dt;

        Koneksi konn = new Koneksi();
        public Form1()
        {
            InitializeComponent();

            this.Text = "GrocerSeeker";

        }

        void LoadComboBox()
        {
            cbLoginAs.Items.Add("Customer");
            cbLoginAs.Items.Add("Vendor");
        }

        private void centerLabel()
        {
            MessageLogin.Left = (this.ClientSize.Width - MessageLogin.Width) / 2;
        }
               
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadComboBox();
            MessageLogin.Visible = false;
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPhone.Text) || string.IsNullOrEmpty(txtPassword.Text) || cbLoginAs.SelectedItem == null || string.IsNullOrEmpty(cbLoginAs.SelectedItem.ToString()))
            {
                MessageLogin.Text = "Harap isi semua field yang disediakan";
                centerLabel();
                MessageLogin.Visible = true;
            }
           
            else
            {
                string Phone = txtPhone.Text;
                string password = txtPassword.Text;
                string loginAs = cbLoginAs.SelectedItem.ToString();

                SqlConnection conn = konn.GetConn();
                conn.Open();

                string checkPhoneQuery = "SELECT * FROM [users] WHERE phone_number = @phone_number";
                cmd = new SqlCommand(checkPhoneQuery, conn);
                cmd.Parameters.AddWithValue("@phone_number", Phone);

                rd = cmd.ExecuteReader();

                if (rd.HasRows)
                {
                    rd.Read();
                    string dbPassword = rd["password"].ToString();
                    int userID = Convert.ToInt32(rd["id"]);
                    string userName = "";

                    if (password != dbPassword)
                    {
                        MessageLogin.Text = "Password yang anda masukkan salah";
                        centerLabel();
                        MessageLogin.Visible = true;
                    }
                    else
                    {
                        if (loginAs == "Customer")
                        {
                            short custActive = rd.GetInt16(rd.GetOrdinal("cust_active"));
                            if (custActive == 0)
                            {
                                MessageLogin.Text = "Akun ini tidak terdaftar sebagai customer";
                                centerLabel();
                                MessageLogin.Visible = true;
                            }
                            else
                            {
                                userName = rd["cust_name"].ToString();
                                this.Hide();
                                new MainForm(userID, userName, loginAs).Show();
                            }
                        }
                        else if (loginAs == "Vendor")
                        {
                            short vendorActive = rd.GetInt16(rd.GetOrdinal("vendor_active"));
                            if (vendorActive == 0)
                            {
                                MessageLogin.Text = "Akun ini tidak terdaftar sebagai vendor";
                                centerLabel();
                                MessageLogin.Visible = true;
                            }
                            else
                            {
                                userName = rd["vendor_name"].ToString();
                                this.Hide();
                                new MainForm(userID, userName, loginAs).Show();
                            }
                        }
                    }
                }
                else
                {
                    MessageLogin.Text = "Nomor Telepon yang anda masukkan tidak ditemukan";
                    centerLabel();
                    MessageLogin.Visible = true;
                }

                conn.Close();
            }
        }



        private void linkSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            new FormCreateAccount().Show();
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                if (!(Control.ModifierKeys == Keys.Control && e.KeyChar == 22))
                {
                    e.Handled = true;
                    MessageLogin.Text = "Anda Hanya Bisa Memasukkan Angka saja";
                    centerLabel();
                    MessageLogin.Visible= true;
                }
            }
        }

        private void txtPhone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.V)
            {
                e.Handled = false;
            }
        }

    }
}
