﻿namespace GrocerSeeker
{
    partial class FormProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cekbVendor = new System.Windows.Forms.CheckBox();
            this.cekbCostomer = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.gbCustomer = new System.Windows.Forms.GroupBox();
            this.txtLongitudeCustomer = new System.Windows.Forms.TextBox();
            this.txtLatitudeCustomer = new System.Windows.Forms.TextBox();
            this.txtAddressCustomer = new System.Windows.Forms.RichTextBox();
            this.txtNameCustomer = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gbVendor = new System.Windows.Forms.GroupBox();
            this.txtLongitudeVendor = new System.Windows.Forms.TextBox();
            this.txtLatitudeVendor = new System.Windows.Forms.TextBox();
            this.txtAddressVendor = new System.Windows.Forms.RichTextBox();
            this.txtNameVendor = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.MessageProfile = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDiscard = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.gbCustomer.SuspendLayout();
            this.gbVendor.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(311, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Your Profile";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(283, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Phone Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(283, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Email";
            // 
            // cekbVendor
            // 
            this.cekbVendor.AutoSize = true;
            this.cekbVendor.Location = new System.Drawing.Point(475, 126);
            this.cekbVendor.Name = "cekbVendor";
            this.cekbVendor.Size = new System.Drawing.Size(60, 17);
            this.cekbVendor.TabIndex = 11;
            this.cekbVendor.Text = "Vendor";
            this.cekbVendor.UseVisualStyleBackColor = true;
            this.cekbVendor.CheckedChanged += new System.EventHandler(this.cekbVendor_CheckedChanged);
            // 
            // cekbCostomer
            // 
            this.cekbCostomer.AutoSize = true;
            this.cekbCostomer.Location = new System.Drawing.Point(389, 126);
            this.cekbCostomer.Name = "cekbCostomer";
            this.cekbCostomer.Size = new System.Drawing.Size(70, 17);
            this.cekbCostomer.TabIndex = 10;
            this.cekbCostomer.Text = "Customer";
            this.cekbCostomer.UseVisualStyleBackColor = true;
            this.cekbCostomer.CheckedChanged += new System.EventHandler(this.cekbCostomer_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(284, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Role Creation";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(389, 48);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(120, 20);
            this.txtPhone.TabIndex = 12;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(389, 84);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(120, 20);
            this.txtEmail.TabIndex = 13;
            // 
            // gbCustomer
            // 
            this.gbCustomer.Controls.Add(this.txtLongitudeCustomer);
            this.gbCustomer.Controls.Add(this.txtLatitudeCustomer);
            this.gbCustomer.Controls.Add(this.txtAddressCustomer);
            this.gbCustomer.Controls.Add(this.txtNameCustomer);
            this.gbCustomer.Controls.Add(this.label11);
            this.gbCustomer.Controls.Add(this.label10);
            this.gbCustomer.Controls.Add(this.label9);
            this.gbCustomer.Controls.Add(this.label8);
            this.gbCustomer.Controls.Add(this.label7);
            this.gbCustomer.Location = new System.Drawing.Point(65, 167);
            this.gbCustomer.Name = "gbCustomer";
            this.gbCustomer.Size = new System.Drawing.Size(325, 177);
            this.gbCustomer.TabIndex = 14;
            this.gbCustomer.TabStop = false;
            this.gbCustomer.Text = "Customer Details";
            // 
            // txtLongitudeCustomer
            // 
            this.txtLongitudeCustomer.Location = new System.Drawing.Point(215, 134);
            this.txtLongitudeCustomer.Name = "txtLongitudeCustomer";
            this.txtLongitudeCustomer.Size = new System.Drawing.Size(87, 20);
            this.txtLongitudeCustomer.TabIndex = 8;
            this.txtLongitudeCustomer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLongitudeCustomer_KeyPress);
            // 
            // txtLatitudeCustomer
            // 
            this.txtLatitudeCustomer.Location = new System.Drawing.Point(68, 134);
            this.txtLatitudeCustomer.Name = "txtLatitudeCustomer";
            this.txtLatitudeCustomer.Size = new System.Drawing.Size(81, 20);
            this.txtLatitudeCustomer.TabIndex = 7;
            this.txtLatitudeCustomer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLatitudeCustomer_KeyPress);
            // 
            // txtAddressCustomer
            // 
            this.txtAddressCustomer.Location = new System.Drawing.Point(68, 58);
            this.txtAddressCustomer.Name = "txtAddressCustomer";
            this.txtAddressCustomer.Size = new System.Drawing.Size(234, 37);
            this.txtAddressCustomer.TabIndex = 6;
            this.txtAddressCustomer.Text = "";
            // 
            // txtNameCustomer
            // 
            this.txtNameCustomer.Location = new System.Drawing.Point(68, 27);
            this.txtNameCustomer.Name = "txtNameCustomer";
            this.txtNameCustomer.Size = new System.Drawing.Size(234, 20);
            this.txtNameCustomer.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(155, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Longitude";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Latitude";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Location";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Address";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Name";
            // 
            // gbVendor
            // 
            this.gbVendor.Controls.Add(this.txtLongitudeVendor);
            this.gbVendor.Controls.Add(this.txtLatitudeVendor);
            this.gbVendor.Controls.Add(this.txtAddressVendor);
            this.gbVendor.Controls.Add(this.txtNameVendor);
            this.gbVendor.Controls.Add(this.label12);
            this.gbVendor.Controls.Add(this.label13);
            this.gbVendor.Controls.Add(this.label14);
            this.gbVendor.Controls.Add(this.label15);
            this.gbVendor.Controls.Add(this.label16);
            this.gbVendor.Location = new System.Drawing.Point(396, 167);
            this.gbVendor.Name = "gbVendor";
            this.gbVendor.Size = new System.Drawing.Size(354, 177);
            this.gbVendor.TabIndex = 15;
            this.gbVendor.TabStop = false;
            this.gbVendor.Text = "Vendor Details";
            // 
            // txtLongitudeVendor
            // 
            this.txtLongitudeVendor.Location = new System.Drawing.Point(245, 131);
            this.txtLongitudeVendor.Name = "txtLongitudeVendor";
            this.txtLongitudeVendor.Size = new System.Drawing.Size(86, 20);
            this.txtLongitudeVendor.TabIndex = 8;
            this.txtLongitudeVendor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLongitudeVendor_KeyPress);
            // 
            // txtLatitudeVendor
            // 
            this.txtLatitudeVendor.Location = new System.Drawing.Point(68, 134);
            this.txtLatitudeVendor.Name = "txtLatitudeVendor";
            this.txtLatitudeVendor.Size = new System.Drawing.Size(96, 20);
            this.txtLatitudeVendor.TabIndex = 7;
            this.txtLatitudeVendor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLatitudeVendor_KeyPress);
            // 
            // txtAddressVendor
            // 
            this.txtAddressVendor.Location = new System.Drawing.Point(68, 58);
            this.txtAddressVendor.Name = "txtAddressVendor";
            this.txtAddressVendor.Size = new System.Drawing.Size(263, 37);
            this.txtAddressVendor.TabIndex = 6;
            this.txtAddressVendor.Text = "";
            // 
            // txtNameVendor
            // 
            this.txtNameVendor.Location = new System.Drawing.Point(68, 27);
            this.txtNameVendor.Name = "txtNameVendor";
            this.txtNameVendor.Size = new System.Drawing.Size(263, 20);
            this.txtNameVendor.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(185, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Longitude";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 137);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Latitude";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Location";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 58);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Name";
            // 
            // MessageProfile
            // 
            this.MessageProfile.AutoSize = true;
            this.MessageProfile.ForeColor = System.Drawing.Color.Red;
            this.MessageProfile.Location = new System.Drawing.Point(377, 360);
            this.MessageProfile.Name = "MessageProfile";
            this.MessageProfile.Size = new System.Drawing.Size(50, 13);
            this.MessageProfile.TabIndex = 16;
            this.MessageProfile.Text = "Message";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(287, 387);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 28);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDiscard
            // 
            this.btnDiscard.Location = new System.Drawing.Point(396, 387);
            this.btnDiscard.Name = "btnDiscard";
            this.btnDiscard.Size = new System.Drawing.Size(103, 28);
            this.btnDiscard.TabIndex = 18;
            this.btnDiscard.Text = "Discard";
            this.btnDiscard.UseVisualStyleBackColor = true;
            this.btnDiscard.Click += new System.EventHandler(this.btnDiscard_Click_1);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(685, 12);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(103, 28);
            this.btnEdit.TabIndex = 19;
            this.btnEdit.Text = "Edit Profile";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // FormProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDiscard);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.MessageProfile);
            this.Controls.Add(this.gbVendor);
            this.Controls.Add(this.gbCustomer);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.cekbVendor);
            this.Controls.Add(this.cekbCostomer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormProfile";
            this.Text = "FormProfile";
            this.Load += new System.EventHandler(this.FormProfile_Load);
            this.gbCustomer.ResumeLayout(false);
            this.gbCustomer.PerformLayout();
            this.gbVendor.ResumeLayout(false);
            this.gbVendor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cekbVendor;
        private System.Windows.Forms.CheckBox cekbCostomer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.GroupBox gbCustomer;
        private System.Windows.Forms.TextBox txtLongitudeCustomer;
        private System.Windows.Forms.TextBox txtLatitudeCustomer;
        private System.Windows.Forms.RichTextBox txtAddressCustomer;
        private System.Windows.Forms.TextBox txtNameCustomer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox gbVendor;
        private System.Windows.Forms.TextBox txtLongitudeVendor;
        private System.Windows.Forms.TextBox txtLatitudeVendor;
        private System.Windows.Forms.RichTextBox txtAddressVendor;
        private System.Windows.Forms.TextBox txtNameVendor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label MessageProfile;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDiscard;
        private System.Windows.Forms.Button btnEdit;
    }
}